package mx.edu.ladm_practica2_floresmedrano

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            if (editText.text.isEmpty() || editText2.text.isEmpty()) {
                AlertDialog.Builder(this).setMessage("Ambos campos de texto son necesarios.").setTitle("MENSAJE").setPositiveButton("OK"){i,d->}.show()
                return@setOnClickListener
            }
            if (radioButton.isChecked==false && radioButton2.isChecked==false) {
                AlertDialog.Builder(this).setMessage("Falta la ubicación.").setTitle("MENSAJE").setPositiveButton("OK"){i,d->}.show()
                return@setOnClickListener
            }
            if (radioButton.isChecked) {
                guardarMemoriaInterna()
            }else{
                guardarMemoriaExterna()
            }
        }
        button2.setOnClickListener {
            if (editText2.text.isEmpty()) {
                AlertDialog.Builder(this).setMessage("Escribe el nombre del archivo.").setTitle("MENSAJE").setPositiveButton("OK"){i,d->}.show()
                return@setOnClickListener
            }
            if (radioButton.isChecked==false && radioButton2.isChecked==false) {
                AlertDialog.Builder(this).setMessage("Elija la fuente del archivo.").setTitle("MENSAJE").setPositiveButton("OK"){i,d->}.show()
                return@setOnClickListener
            }
            if (radioButton.isChecked) {
                leerMemoriaInterna()
            }else{
                leerMemoriaExterna()
            }
        }
    }

    private fun guardarMemoriaInterna() {
        try {
            var flujoDeSalida = OutputStreamWriter(
                openFileOutput(editText2.text.toString(), Context.MODE_PRIVATE)
            )
            var data = editText.text.toString()
            flujoDeSalida.write(data)
            flujoDeSalida.flush()
            flujoDeSalida.close()
            AlertDialog.Builder(this).setMessage("Se creo el archivo correctamente").setTitle("COMPLETO").setPositiveButton("OK"){i,d->}.show()
        } catch (error: IOException) {

        }
    }
    fun leerMemoriaInterna() {
        try {
            var flujoDeEntrada = BufferedReader(InputStreamReader(openFileInput(editText2.text.toString())))
            var data = flujoDeEntrada.readLine()
            editText.setText(data)
        } catch (error: IOException) {
        }
    }
    private fun guardarMemoriaExterna() {
        var archivo = File(getExternalFilesDir("MyDirectory"), editText2.text.toString())
        try {
            val flujoDeSalida = FileOutputStream(archivo)
            flujoDeSalida.write(editText.text.toString().toByteArray())
            flujoDeSalida.close()
            AlertDialog.Builder(this).setMessage("Se creo el archivo correctamente").setTitle("COMPLETO").setPositiveButton("OK"){i,d->}.show()
        } catch (error: IOException) {
        }
    }

    fun leerMemoriaExterna() {
        var archivo = File(getExternalFilesDir("MyDirectory"), editText2.text.toString())
            var flujoDeEntrada = FileInputStream(archivo)
            var inputStreamReader = InputStreamReader(flujoDeEntrada)
            val bufferedReader = BufferedReader(inputStreamReader)
            var data: String? = null
            while ({ data = bufferedReader.readLine(); data }() != null) {
                editText.setText(data)
            }
            flujoDeEntrada.close()
    }
}
